self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "befaa1b406d606a15abc3e449831e3e2",
    "url": "/invertebrae/index.html"
  },
  {
    "revision": "60826b8e88222f4e97fc",
    "url": "/invertebrae/static/css/main.cf5db718.chunk.css"
  },
  {
    "revision": "fb73b043f03557a3a11b",
    "url": "/invertebrae/static/js/2.90d0a0bd.chunk.js"
  },
  {
    "revision": "60826b8e88222f4e97fc",
    "url": "/invertebrae/static/js/main.d443a13c.chunk.js"
  },
  {
    "revision": "dd5faf35e7f54655ac52",
    "url": "/invertebrae/static/js/runtime~main.afbf7f8b.js"
  },
  {
    "revision": "473ea72ae3331ae38d649a08d10096c8",
    "url": "/invertebrae/static/media/terminal-grotesque.473ea72a.ttf"
  }
]);